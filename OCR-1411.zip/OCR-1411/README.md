# OCR
Fast OCR with Tesseract
