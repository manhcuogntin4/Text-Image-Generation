/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   outil.cpp
 * Author: cuong_nguyen
 * 
 * Created on October 18, 2016, 3:56 PM
 */

#include "outil.h"

outil::outil() {
}

outil::outil(const outil& orig) {
}

outil::~outil() {
}

