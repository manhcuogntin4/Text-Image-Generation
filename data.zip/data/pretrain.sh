#!/bin/bash
cnt=1
while [  $cnt -lt 1295 ]; do
    echo The counter is $cnt
    mkdir $cnt
    mv ${cnt}.* $cnt
    let cnt=cnt+1
done
